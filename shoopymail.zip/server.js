// ============================================================
// ShoopyMail - OkeConnect H2H Proxy
// server.js
// ============================================================

require('dotenv').config();

const express = require('express');
const axios = require('axios');
const { createClient } = require('@supabase/supabase-js');
const WebSocket = require('ws');

const app = express();

// ============================================================
// CONFIG
// ============================================================

const PORT = process.env.PORT || 3000;

const MEMBER_ID = process.env.OKECONNECT_MEMBER_ID;
const PIN = process.env.OKECONNECT_PIN;
const PASSWORD = process.env.OKECONNECT_PASSWORD;
const BASE_URL = process.env.OKECONNECT_BASE_URL;

const SECRET_TOKEN = process.env.PROXY_SECRET_TOKEN;

const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_KEY;

// ============================================================
// SUPABASE
// ============================================================

const supabase = createClient(
  SUPABASE_URL,
  SUPABASE_SERVICE_KEY,
  {
    realtime: {
      transport: WebSocket
    }
  }
);

// ============================================================
// CORS
// ============================================================

app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header(
    'Access-Control-Allow-Headers',
    'Content-Type, x-proxy-token'
  );
  res.header(
    'Access-Control-Allow-Methods',
    'GET, POST, OPTIONS'
  );

  if (req.method === 'OPTIONS') {
    return res.sendStatus(204);
  }

  next();
});

// ============================================================
// BODY PARSER
// ============================================================

app.use(express.json());

// ============================================================
// HELPER - PARSE OKECONNECT STATUS
// ============================================================

function parseOkeStatus(text) {
  const t = String(text || '').toUpperCase();

  if (
    t.includes('GAGAL') ||
    t.includes('FAIL')
  ) {
    return 'failed';
  }

  if (
    t.includes('SUKSES') ||
    t.includes('SUCCESS')
  ) {
    return 'completed';
  }

  if (
    t.includes('PROSES') ||
    t.includes('DITERIMA')
  ) {
    return 'processing';
  }

  return 'processing';
}

// ============================================================
// HELPER - GENERATE UNIQUE REF ID
// ============================================================

function generateRefID() {
  const timestamp = Date.now();
  const random = Math.floor(
    1000 + Math.random() * 9000
  );

  return `SHOOPY_${timestamp}_${random}`;
}

// ============================================================
// HELPER - AUTH
// ============================================================

function authMiddleware(req, res, next) {
  const token = req.headers['x-proxy-token'];

  if (!SECRET_TOKEN) {
    console.error(
      '[AUTH ERROR] PROXY_SECRET_TOKEN belum diset.'
    );

    return res.status(500).json({
      success: false,
      message: 'Proxy secret belum dikonfigurasi.'
    });
  }

  if (token !== SECRET_TOKEN) {
    console.log(
      '[AUTH FAIL] Invalid token from',
      req.ip
    );

    return res.status(401).json({
      success: false,
      message: 'Unauthorized'
    });
  }

  next();
}

// ============================================================
// ENDPOINT 1
// POST /withdraw
//
// Mendukung:
//
// FORMAT E-WALLET DASHBOARD:
// {
//   ref,
//   amount,
//   ewallet,
//   phone,
//   withdraw_id
// }
//
// FORMAT PULSA:
// {
//   product_code,
//   customer_number,
//   withdraw_id
// }
// ============================================================

app.post(
  '/withdraw',
  authMiddleware,
  async (req, res) => {

    try {

      const body = req.body || {};

      let {
        product_code,
        customer_number,
        withdraw_id
      } = body;

      // --------------------------------------------------------
      // COMPATIBILITY DENGAN FORMAT WITHDRAW E-WALLET LAMA
      // --------------------------------------------------------

      const {
        ref,
        amount,
        ewallet,
        phone
      } = body;

      // Kalau dashboard mengirim:
      // ewallet + phone
      //
      // ubah menjadi:
      // product_code + customer_number
      //
      // Contoh:
      // DANA + 081234...
      // menjadi D + nominal-ribu
      //
      // NOTE:
      // Kalau product_code sudah tersedia, kita prioritaskan itu.

      if (!product_code && ewallet && amount) {

        const prefixMap = {
          dana: 'D',
          ovo: 'OVO',
          gopay: 'GPY',
          shopeepay: 'SHP'
        };

        const walletKey = String(
          ewallet
        ).toLowerCase();

        const prefix = prefixMap[walletKey];

        if (!prefix) {
          return res.status(400).json({
            success: false,
            message: `E-wallet tidak dikenal: ${ewallet}`
          });
        }

        const nominalRibu = Math.floor(
          Number(amount) / 1000
        );

        if (!nominalRibu || nominalRibu <= 0) {
          return res.status(400).json({
            success: false,
            message: 'Nominal tidak valid.'
          });
        }

        product_code =
          `${prefix}${nominalRibu}`;
      }

      // Format destination
      if (!customer_number && phone) {
        customer_number = phone;
      }

      // --------------------------------------------------------
      // VALIDASI
      // --------------------------------------------------------

      if (!product_code) {
        return res.status(400).json({
          success: false,
          message: 'Missing product_code.'
        });
      }

      if (!customer_number) {
        return res.status(400).json({
          success: false,
          message: 'Missing customer_number.'
        });
      }

      // --------------------------------------------------------
      // GENERATE REF
      // --------------------------------------------------------

      const refID = generateRefID();

      console.log(
        `[WITHDRAW] Start: ${product_code} -> ${customer_number}`
      );

      console.log(
        `[WITHDRAW] withdraw_id=${withdraw_id || '-'}`
      );

      console.log(
        `[WITHDRAW] frontend_ref=${ref || '-'}`
      );

      // --------------------------------------------------------
      // BUILD OKECONNECT PARAMS
      // --------------------------------------------------------

      const params = new URLSearchParams({
        product: String(product_code),
        dest: String(customer_number),
        refID: refID,
        memberID: MEMBER_ID,
        pin: PIN,
        password: PASSWORD
      });

      // --------------------------------------------------------
      // REQUEST KE OKECONNECT
      // --------------------------------------------------------

      const okeResponse = await axios.get(
        `${BASE_URL}?${params.toString()}`,
        {
          timeout: 30000
        }
      );

      const responseText =
        String(okeResponse.data);

      console.log(
        `[WITHDRAW] OkeConnect response: ${responseText}`
      );

      // --------------------------------------------------------
      // PARSE STATUS
      // --------------------------------------------------------

      const trxStatus =
        parseOkeStatus(responseText);

      // --------------------------------------------------------
      // UPDATE SUPABASE
      // --------------------------------------------------------

      if (withdraw_id) {

        const {
          error: updateErr
        } = await supabase
          .from('withdraw_requests')
          .update({
            okeconnect_ref_id: refID,
            okeconnect_response: responseText,
            status: trxStatus,
            updated_at:
              new Date().toISOString()
          })
          .eq('id', withdraw_id);

        if (updateErr) {
          console.error(
            '[DB ERROR] Failed to update withdraw_requests:',
            updateErr.message
          );
        }
      }

      // --------------------------------------------------------
      // RESPONSE KE DASHBOARD
      // --------------------------------------------------------

      return res.json({
        success: trxStatus !== 'failed',
        status: trxStatus,
        ref_id: refID,
        message: responseText,
        withdraw_id: withdraw_id || null
      });

    } catch (err) {

      console.error(
        '[WITHDRAW ERROR]',
        err.message
      );

      return res.status(500).json({
        success: false,
        message: err.message
      });
    }
  }
);

// ============================================================
// ENDPOINT 2
// GET /callback
//
// Callback dari OkeConnect
// ============================================================

app.get(
  '/callback',
  async (req, res) => {

    try {

      const {
        refid,
        message
      } = req.query;

      console.log(
        `[CALLBACK] refid=${refid} | message=${message}`
      );

      if (!refid || !message) {
        return res
          .status(400)
          .send('Missing params');
      }

      const finalStatus =
        parseOkeStatus(message);

      const updateData = {
        status: finalStatus,
        okeconnect_callback_message:
          String(message),
        updated_at:
          new Date().toISOString()
      };

      if (finalStatus === 'completed') {
        updateData.completed_at =
          new Date().toISOString();
      }

      const {
        error
      } = await supabase
        .from('withdraw_requests')
        .update(updateData)
        .eq('okeconnect_ref_id', refid);

      if (error) {

        console.error(
          '[CALLBACK DB ERROR]',
          error.message
        );

        return res
          .status(500)
          .send('DB Error');
      }

      console.log(
        `[CALLBACK] Updated refid=${refid} -> status=${finalStatus}`
      );

      return res.send('OK');

    } catch (err) {

      console.error(
        '[CALLBACK ERROR]',
        err.message
      );

      return res
        .status(500)
        .send('Error');
    }
  }
);

// ============================================================
// ENDPOINT 3
// POST /check-status
//
// Manual fallback polling
// ============================================================

app.post(
  '/check-status',
  authMiddleware,
  async (req, res) => {

    try {

      const {
        product_code,
        customer_number,
        ref_id,
        withdraw_id
      } = req.body || {};

      if (!product_code) {
        return res.status(400).json({
          success: false,
          message: 'Missing product_code.'
        });
      }

      if (!customer_number) {
        return res.status(400).json({
          success: false,
          message: 'Missing customer_number.'
        });
      }

      if (!ref_id) {
        return res.status(400).json({
          success: false,
          message: 'Missing ref_id.'
        });
      }

      // --------------------------------------------------------
      // OKECONNECT CHECK PARAMS
      // --------------------------------------------------------

      const params = new URLSearchParams({
        product: String(product_code),
        dest: String(customer_number),
        refID: String(ref_id),
        memberID: MEMBER_ID,
        pin: PIN,
        password: PASSWORD,
        check: '1'
      });

      // --------------------------------------------------------
      // REQUEST
      // --------------------------------------------------------

      const okeResponse = await axios.get(
        `${BASE_URL}?${params.toString()}`,
        {
          timeout: 30000
        }
      );

      const responseText =
        String(okeResponse.data);

      console.log(
        `[CHECK-STATUS] refID=${ref_id} | response: ${responseText}`
      );

      // --------------------------------------------------------
      // PARSE
      // --------------------------------------------------------

      const finalStatus =
        parseOkeStatus(responseText);

      // --------------------------------------------------------
      // UPDATE DB
      // --------------------------------------------------------

      if (
        finalStatus === 'completed' ||
        finalStatus === 'failed'
      ) {

        const updateData = {
          status: finalStatus,
          okeconnect_callback_message:
            responseText,
          updated_at:
            new Date().toISOString()
        };

        if (finalStatus === 'completed') {
          updateData.completed_at =
            new Date().toISOString();
        }

        const {
          error
        } = await supabase
          .from('withdraw_requests')
          .update(updateData)
          .eq('okeconnect_ref_id', ref_id);

        if (error) {
          console.error(
            '[CHECK-STATUS DB ERROR]',
            error.message
          );
        }
      }

      // --------------------------------------------------------
      // RESPONSE
      // --------------------------------------------------------

      return res.json({
        success: true,
        status: finalStatus,
        message: responseText,
        withdraw_id:
          withdraw_id || null
      });

    } catch (err) {

      console.error(
        '[CHECK-STATUS ERROR]',
        err.message
      );

      return res.status(500).json({
        success: false,
        message: err.message
      });
    }
  }
);

// ============================================================
// HEALTH CHECK
// ============================================================

app.get('/', (req, res) => {

  res.json({
    status: 'ok',
    service: 'ShoopyMail OkeConnect Proxy',
    time: new Date().toISOString()
  });

});

// ============================================================
// START SERVER
// ============================================================

app.listen(
  PORT,
  '0.0.0.0',
  () => {

    console.log(
      `🚀 ShoopyMail Proxy running on port ${PORT}`
    );

    console.log(
      `📡 Callback URL: http://202.155.16.135:${PORT}/callback`
    );

    console.log(
      `🔑 Member ID: ${MEMBER_ID || '(not set)'}`
    );

    console.log(
      `🌐 OkeConnect Base URL: ${BASE_URL || '(not set)'}`
    );
  }
);